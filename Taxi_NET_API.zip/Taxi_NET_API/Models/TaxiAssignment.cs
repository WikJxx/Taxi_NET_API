namespace Taxi_NET_API.Models;

public class TaxiAssignment 
{
     public int TaxiAssignmentID{get; set;}
     public int TaxiDriverID {get; set;}
     public bool IsElectric {get;set;}
     public int TaxiID {get; set;}

}