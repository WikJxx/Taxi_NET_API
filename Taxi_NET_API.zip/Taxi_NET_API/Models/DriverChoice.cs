namespace Taxi_NET_API.Models;

    public class DriverChoice
    {
        public int DriverChoiceID {get; set;}
        public int TaxiDriverID {get; set;}
        public int TripID {get; set;}
    }
