namespace Taxi_NET_API.Models;
public class CombustionTaxi :Taxi
{
    public int CombustionTaxiID {get; set;}
    public string? FuelType {get; set;}
}