namespace Taxi_NET_API.Models;
public class ElectricTaxi : Taxi
{
    public int electricTaxiID {get; set;}
    public int batteryCapacity {get; set;}
}